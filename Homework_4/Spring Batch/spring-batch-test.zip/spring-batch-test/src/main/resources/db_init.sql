CREATE SCHEMA main;
CREATE TABLE users(
    firstName VARCHAR(128),
    lastName VARCHAR(128),
    balance FLOAT,
    email VARCHAR(128)
);
INSERT INTO users (firstName, lastName, balance, email)
VALUES (
        'oleg', 'svidunov', 8.45, 'svidunov1@gmail.com'
       );